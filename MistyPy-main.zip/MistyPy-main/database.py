

# Menu
title = 'Misty'
subtitle = 'An Elemental Adventure'
init_text = '              Press Enter to Start'

# Character
class Player:
    name = 'Misty'.title()
    element = 'Fire'
    attack = 0
    defense = 0
    faith = 0
    power = 0
    fear = 0
