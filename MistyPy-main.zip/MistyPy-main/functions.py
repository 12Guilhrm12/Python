#Librarys
from art import *
from colorama import Fore
from colorama import Style
from playsound3 import playsound
import time
from database import *
import os
import sys

# Variables
points = 12
_loop = 1

# Functions

def print_dgt(txt, spd, brk):
    for i in txt:
        sys.stdout.write(i)
        sys.stdout.flush()
        time.sleep(spd)
    if brk == 1:
        print()


def cls():
    os.system('cls')
    return

def title(_title):
    print(f"{Fore.RED}")
    tprint(_title, "roman")
    playsound("sound/theme.mp3")
    time.sleep(1)
    print(f"{Fore.YELLOW}        ---- {subtitle} ----       {Style.RESET_ALL}")
    return

def check_chara():
    global _loop
    _c = 1

    while (_loop == 1):
                       
            print_dgt(f'{Fore.CYAN}Is this correct? {Fore.CYAN}({Fore.GREEN}Y{Fore.CYAN}/{Fore.RED}N{Fore.CYAN}): ', 0.05, 0); loop = input().upper()
            if (loop == 'Y'):
                _loop = 0
                _c = 0
            elif (loop == 'N'):
                _loop = 0
                _c = 1
                cls()
            else:
                _c = 1
                _loop = 1
                print_dgt('Please, insert a correct value!', 0.05, 1)

    return _c

def create_character():
    _naming = 1
    _elementing = 1

    print_dgt(f'{Fore.CYAN}Create your Character', 0.07, 1)
    while (_naming == 1):
        time.sleep(1)
        print_dgt(f'Enter your name (Default name Misty):{Fore.RED} ', 0.05, 0); name = input().strip().title() or 'Misty'
        time.sleep(1)
        cls()
        Player.name = name
        print_dgt(f'{Fore.CYAN}Your name is {Fore.RED}' + str(Player.name), 0.07, 1)

        lp = check_chara()
        _naming = lp
        
    while (_elementing == 1):
        global points
        cls()

        if points > 0:
            time.sleep(1)
            _text1 = str(f'{Fore.CYAN}God gave you {Fore.YELLOW}' + str(points) + f'{Fore.CYAN} points')
            _text2 = str(f'You have {Fore.YELLOW}' + str(points) + f'{Fore.CYAN} points left')
            print( _text1 if points == 12 else _text2); time.sleep(1)
            print('Choose your stats:')

            print('1) Attack: ' + str(Player.attack)  )
            print('2) Defense: ' + str(Player.defense))
            print('3) Power: ' + str(Player.power)    )
            print('4) Faith: ' + str(Player.faith)    )
            print('5) Fear: ' + str(Player.fear)      )
            print()

            _point = input('Choose 1 to up (Costs 1 point): ').strip()

            match (_point):
                case str('1'):
                    Player.attack += 1
                    points -= 1
                case str('2'):
                    Player.defense += 1
                    points -= 1
                case str('3'):
                    Player.power += 1
                    points -= 1
                case str('4'):
                    Player.faith += 1
                    points -= 1
                case str('5'):
                    Player.fear += 1
                    points -= 1
        else:
            _elementing = 0   
        
                
    cls()
    print_dgt(f'{Fore.CYAN}Here is your Stats\n', 0.08, 1)
    print_dgt(f'{Fore.CYAN}Name: \n' + str(Player.name), 0.08, 1)
        
