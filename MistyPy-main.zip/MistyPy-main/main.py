#Librarys
import database
from functions import *
import sys

# os.system("mode con: cols=100 lines=30")
cls()

#Show Title
title(database.title)

#Init the Game
print(database.init_text); input()
cls()
 
create_character()

input('Press Enter to Exit...')
